#include <stdio.h>

int main(void)
{
  printf("Hello World!\n\tCreated by Patrik (c) 2015\n");

  return 0;
}
